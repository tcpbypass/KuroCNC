Kuro CNC
========
Developed By Bane On a random ass sunday night

SETUP INSTRUCTIONS:
1. Run the binary with the -setup flag to configure the CNC:
   ./KuroCnc -setup  (Linux/Mac)
   KuroCnc.exe -setup  (Windows)

2. After setup, run the binary without flags to start the CNC server:
   ./KuroCnc  (Linux/Mac)
   KuroCnc.exe  (Windows)

CUSTOMIZATION:
- Configuration files are stored in the "configs" directory
- Template files for UI elements are in the "templates" directory
- Logs are saved in the "logs" directory

For questions and support, contact the developer.
